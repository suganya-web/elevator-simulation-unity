using UnityEngine;
using UnityEngine.UI;

public class FloorButton : MonoBehaviour
{
    public int floorNumber;
    public ElevatorManager manager;
    public Button btn;

    public void OnButtonClick()
    {
        manager.RequestElevator(floorNumber);

        // disable button after click
        btn.interactable = false;
    }
}
