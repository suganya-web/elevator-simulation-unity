using UnityEngine;

public class ElevatorManager : MonoBehaviour
{
    public ElevatorController[] elevators;

    public void RequestElevator(int floor)
    {
        ElevatorController bestElevator = null;
        float minDistance = Mathf.Infinity;

        foreach (var elevator in elevators)
        {
            float distance = Mathf.Abs(elevator.GetCurrentFloor() - floor);

            // Same direction priority
            if (elevator.currentDirection == ElevatorController.Direction.Up && floor > elevator.GetCurrentFloor())
            {
                if (distance < minDistance)
                {
                    minDistance = distance;
                    bestElevator = elevator;
                }
            }
            else if (elevator.currentDirection == ElevatorController.Direction.Down && floor < elevator.GetCurrentFloor())
            {
                if (distance < minDistance)
                {
                    minDistance = distance;
                    bestElevator = elevator;
                }
            }
        }

        // If none found → choose idle
        if (bestElevator == null)
        {
            foreach (var elevator in elevators)
            {
                if (elevator.IsIdle())
                {
                    float distance = Mathf.Abs(elevator.GetCurrentFloor() - floor);

                    if (distance < minDistance)
                    {
                        minDistance = distance;
                        bestElevator = elevator;
                    }
                }
            }
        }

        if (bestElevator != null)
        {
            bestElevator.AddRequest(floor);
        }
    }
}



