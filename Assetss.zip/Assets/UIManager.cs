using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    public Button[] buttons;

    public void EnableButton(int floor)
    {
        buttons[floor].interactable = true;
    }
}

