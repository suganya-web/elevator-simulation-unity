using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElevatorController : MonoBehaviour
{
    public float speed = 2f;
    public float floorHeight = 3f;

    private Queue<int> requestQueue = new Queue<int>();
    private bool isMoving = false;

    private int currentFloor = 0;
    private int targetFloor = 0;

    public enum Direction
    {
        Idle,
        Up,
        Down
    }

    public Direction currentDirection = Direction.Idle;

    void Update()
    {
        if (!isMoving && requestQueue.Count > 0)
        {
            targetFloor = requestQueue.Dequeue();
            StartCoroutine(MoveToFloor(targetFloor));
        }
    }

    public void AddRequest(int floor)
    {
        requestQueue.Enqueue(floor);
    }

    IEnumerator MoveToFloor(int floor)
    {
        isMoving = true;

        // Set direction
        if (floor > currentFloor)
            currentDirection = Direction.Up;
        else if (floor < currentFloor)
            currentDirection = Direction.Down;
        else
            currentDirection = Direction.Idle;

        Debug.Log("Direction: " + currentDirection);

        Vector3 targetPosition = new Vector3(transform.position.x, floor * floorHeight, transform.position.z);

        while (Vector3.Distance(transform.position, targetPosition) > 0.05f)
        {
            transform.position = Vector3.MoveTowards(transform.position, targetPosition, speed * Time.deltaTime);
            yield return null;
        }

        transform.position = targetPosition;
        currentFloor = floor;

        // Enable button again
        FindObjectOfType<UIManager>().EnableButton(currentFloor);

        yield return new WaitForSeconds(1f);

        isMoving = false;

        if (requestQueue.Count == 0)
            currentDirection = Direction.Idle;
    }

    public int GetCurrentFloor()
    {
        return currentFloor;
    }

    public bool IsIdle()
    {
        return requestQueue.Count == 0 && !isMoving;
    }
}


